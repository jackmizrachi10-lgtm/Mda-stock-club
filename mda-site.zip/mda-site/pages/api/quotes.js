// pages/api/quotes.js
// Proxies Yahoo Finance for real-time stock quotes
// No API key needed — Yahoo Finance public endpoint

export default async function handler(req, res) {
  const { symbols } = req.query;
  if (!symbols) return res.status(400).json({ error: "symbols param required" });

  try {
    const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${encodeURIComponent(symbols)}`;
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
    });

    if (!response.ok) {
      // Fallback: try v6 endpoint
      const url2 = `https://query2.finance.yahoo.com/v6/finance/quote?symbols=${encodeURIComponent(symbols)}`;
      const r2 = await fetch(url2, {
        headers: { "User-Agent": "Mozilla/5.0" },
      });
      if (!r2.ok) throw new Error("Yahoo Finance unavailable");
      const d2 = await r2.json();
      return res.status(200).json(d2);
    }

    const data = await response.json();
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
