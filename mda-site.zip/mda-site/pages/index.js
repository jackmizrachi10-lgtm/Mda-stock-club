import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import Head from "next/head";

const STARTING_CASH = 5000;
const G = "#00e676", R = "#ff1744", BG = "#060609", C1 = "#0c0c12", C2 = "#101018", BD = "#1a1a26", MT = "#55556a", TX = "#dddde8";
const fmt = (n) => "$" + Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/* Default watchlist */
const DEFAULT_SYMBOLS = [
  "AAPL","MSFT","GOOGL","AMZN","NVDA","META","TSLA","AMD","NFLX","ADBE",
  "INTC","PLTR","COIN","PYPL","CRM","JPM","V","JNJ","WMT","DIS",
  "BA","GS","KO","MCD","HD","NKE","PG","UNH","XOM","CVX",
  "ABBV","PFE","MRK","LMT","T","VZ","COST","SOFI","RIVN","MARA",
  "SPY","QQQ","IWM","GLD","BTC-USD","ETH-USD",
];

/* ═══════ TradingView Chart ═══════ */
function TVChart({ symbol }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return;
    ref.current.innerHTML = "";
    const tvSymbol = symbol === "BTC-USD" ? "BITSTAMP:BTCUSD" : symbol === "ETH-USD" ? "BITSTAMP:ETHUSD" : symbol.includes(":") ? symbol : `NASDAQ:${symbol}`;
    const s = document.createElement("script");
    s.src = "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js";
    s.async = true;
    s.innerHTML = JSON.stringify({ autosize: true, symbol: tvSymbol, interval: "1", timezone: "America/New_York", theme: "dark", style: "1", locale: "en", backgroundColor: C1, gridColor: BD, hide_top_toolbar: false, hide_legend: false, allow_symbol_change: true, save_image: false, calendar: false, support_host: "https://www.tradingview.com" });
    ref.current.appendChild(s);
  }, [symbol]);
  return <div ref={ref} style={{ height: "100%", width: "100%" }} />;
}

function TVTicker() {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return;
    ref.current.innerHTML = "";
    const s = document.createElement("script");
    s.src = "https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js";
    s.async = true;
    s.innerHTML = JSON.stringify({ symbols: [{ proName: "FOREXCOM:SPXUSD", title: "S&P 500" }, { proName: "NASDAQ:AAPL", title: "Apple" }, { proName: "NASDAQ:NVDA", title: "NVIDIA" }, { proName: "NASDAQ:TSLA", title: "Tesla" }, { proName: "NASDAQ:MSFT", title: "Microsoft" }, { proName: "NASDAQ:AMZN", title: "Amazon" }, { proName: "NASDAQ:META", title: "Meta" }, { proName: "NYSE:JPM", title: "JPMorgan" }, { proName: "BITSTAMP:BTCUSD", title: "Bitcoin" }], showSymbolLogo: true, isTransparent: true, displayMode: "adaptive", colorTheme: "dark", locale: "en" });
    ref.current.appendChild(s);
  }, []);
  return <div ref={ref} />;
}

/* ═══════ AI Analysis ═══════ */
const BUILT_IN = {
  AAPL: { rating: "BUY", confidence: 78, target_price: 280, sentiment: "bullish", factors: ["AirPods Max 2 launch", "MotionVFX acquisition", "Services revenue growth"], summary: "Apple well-positioned with ecosystem expansion and new launches. Services revenue major growth driver.", consensus: "Majority Buy, avg target ~$280", risk: "low" },
  NVDA: { rating: "STRONG BUY", confidence: 85, target_price: 220, sentiment: "bullish", factors: ["GTC 2026 AI momentum", "Data center exponential growth", "Nebius $2B investment"], summary: "Dominant AI compute position reinforced at GTC 2026. Next-gen architectures widening moat.", consensus: "Overwhelming Strong Buy, $200-250", risk: "medium" },
  TSLA: { rating: "HOLD", confidence: 55, target_price: 380, sentiment: "neutral", factors: ["~11% YTD decline", "EV competition intensifying", "Autonomous driving catalyst"], summary: "Mixed outlook — competition vs autonomous driving and energy storage catalysts.", consensus: "Split — equal Buy and Hold", risk: "high" },
  MSFT: { rating: "BUY", confidence: 80, target_price: 450, sentiment: "bullish", factors: ["Azure AI workload growth", "Copilot enterprise adoption", "Strong balance sheet"], summary: "Cloud and AI executing well. Azure boosted by AI demand.", consensus: "Strong Buy, $430-470", risk: "low" },
  META: { rating: "STRONG BUY", confidence: 82, target_price: 700, sentiment: "bullish", factors: ["AI ad targeting boosting RPU", "Reality Labs early traction", "Aggressive buyback"], summary: "AI-enhanced advertising driving revenue. Reality Labs losses narrowing.", consensus: "Strong Buy, $650-750", risk: "medium" },
  GOOGL: { rating: "BUY", confidence: 75, target_price: 340, sentiment: "bullish", factors: ["Search resilient", "Cloud accelerating", "Gemini AI traction"], summary: "Search moat intact, expanding cloud and AI.", consensus: "Buy, ~$340", risk: "low" },
  AMZN: { rating: "BUY", confidence: 77, target_price: 240, sentiment: "bullish", factors: ["AWS cloud leadership", "Retail margin expansion", "Ad business scaling"], summary: "Multi-engine growth. AWS leads, ads scaling rapidly.", consensus: "Strong Buy, $230-260", risk: "low" },
  JPM: { rating: "BUY", confidence: 76, target_price: 310, sentiment: "bullish", factors: ["NII strong", "IB recovery", "$20B AI investment"], summary: "Diversified model benefiting. 22/28 analysts Buy.", consensus: "Bullish, $270-310", risk: "low" },
};

function AIModal({ ticker, onClose }) {
  const [result, setResult] = useState(null);
  useEffect(() => {
    setResult(BUILT_IN[ticker] || { rating: "HOLD", confidence: 50, target_price: 0, sentiment: "neutral", factors: ["Research further", "Check earnings", "Review sector"], summary: `Limited data for ${ticker}. Research before trading.`, consensus: "Mixed", risk: "medium" });
  }, [ticker]);
  const rc = { "STRONG BUY": G, "BUY": "#4caf50", "HOLD": "#ff9800", "SELL": "#ff5722", "STRONG SELL": R };
  if (!result) return null;
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,.75)", backdropFilter: "blur(10px)" }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ background: C1, border: `1px solid ${BD}`, borderRadius: 16, width: 520, maxHeight: "85vh", overflow: "auto", padding: 28, animation: "slideUp .3s ease" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <h3 style={{ fontSize: 18, fontWeight: 800 }}>AI Analysis — {ticker}</h3>
          <button onClick={onClose} style={{ background: "none", border: "none", color: MT, cursor: "pointer", fontSize: 20 }}>✕</button>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ padding: "8px 18px", borderRadius: 10, background: `${rc[result.rating] || MT}15`, border: `1px solid ${rc[result.rating] || MT}40`, fontSize: 18, fontWeight: 900, color: rc[result.rating] || TX, fontFamily: "'JetBrains Mono'" }}>{result.rating}</div>
            <div><div style={{ fontSize: 10, color: MT, marginBottom: 3 }}>Confidence</div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}><div style={{ width: 80, height: 5, borderRadius: 3, background: BD }}><div style={{ width: `${result.confidence}%`, height: "100%", borderRadius: 3, background: rc[result.rating] || G }} /></div><span className="mono" style={{ fontSize: 13, fontWeight: 700 }}>{result.confidence}%</span></div></div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
            {[{ l: "Target", v: result.target_price ? "$" + result.target_price : "N/A" }, { l: "Sentiment", v: (result.sentiment || "").toUpperCase() }, { l: "Risk", v: (result.risk || "").toUpperCase() }].map((s, i) => (
              <div key={i} style={{ background: C2, borderRadius: 8, padding: "8px 10px" }}><div style={{ fontSize: 9, color: MT, textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 2 }}>{s.l}</div><div className="mono" style={{ fontSize: 13, fontWeight: 700 }}>{s.v}</div></div>
            ))}
          </div>
          <div><div style={{ fontSize: 10, color: MT, textTransform: "uppercase", marginBottom: 5 }}>Summary</div><div style={{ fontSize: 13, lineHeight: 1.6 }}>{result.summary}</div></div>
          <div><div style={{ fontSize: 10, color: MT, textTransform: "uppercase", marginBottom: 5 }}>Key Factors</div>
            {(result.factors || []).map((f, i) => <div key={i} style={{ fontSize: 13, marginBottom: 3 }}><span style={{ color: G }}>→</span> {f}</div>)}
          </div>
          {result.consensus && <div><div style={{ fontSize: 10, color: MT, textTransform: "uppercase", marginBottom: 5 }}>Consensus</div><div style={{ fontSize: 13 }}>{result.consensus}</div></div>}
          <div style={{ fontSize: 9, color: MT, textAlign: "center", paddingTop: 8, borderTop: `1px solid ${BD}` }}>Educational simulation only. Not financial advice.</div>
        </div>
      </div>
    </div>
  );
}

/* ═══════ MAIN APP ═══════ */
export default function Home() {
  const [page, setPage] = useState("home");
  const [symbol, setSymbol] = useState("AAPL");
  const [searchInput, setSearchInput] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [quotes, setQuotes] = useState({}); // { AAPL: { price, change, changePercent, name }, ... }
  const [portfolio, setPortfolio] = useState({ cash: STARTING_CASH, positions: [], trades: [] });
  const [tradeModal, setTradeModal] = useState(null);
  const [tradeQty, setTradeQty] = useState(1);
  const [strikePrice, setStrikePrice] = useState("");
  const [expiry, setExpiry] = useState("2026-04-17");
  const [showAI, setShowAI] = useState(false);
  const [notification, setNotification] = useState(null);
  const [leaderboard, setLeaderboard] = useState([]);
  const [regForm, setRegForm] = useState({ username: "", email: "" });
  const [registered, setRegistered] = useState(null);
  const [showRegister, setShowRegister] = useState(false);

  const notify = (msg, type = "success") => { setNotification({ msg, type }); setTimeout(() => setNotification(null), 3500); };

  /* ═══ REAL PRICE FETCHING ═══ */
  const fetchQuotes = useCallback(async (symbols) => {
    try {
      const res = await fetch(`/api/quotes?symbols=${symbols.join(",")}`);
      if (!res.ok) return;
      const data = await res.json();
      const results = data?.quoteResponse?.result || [];
      const newQuotes = {};
      results.forEach(q => {
        newQuotes[q.symbol] = {
          price: q.regularMarketPrice || 0,
          change: q.regularMarketChange || 0,
          changePercent: q.regularMarketChangePercent || 0,
          name: q.shortName || q.longName || q.symbol,
          marketState: q.marketState,
          preMarket: q.preMarketPrice,
          postMarket: q.postMarketPrice,
        };
      });
      setQuotes(prev => ({ ...prev, ...newQuotes }));
    } catch (e) { console.error("Quote fetch failed:", e); }
  }, []);

  /* Fetch all watchlist prices on mount + every 10 seconds */
  useEffect(() => {
    fetchQuotes(DEFAULT_SYMBOLS);
    const interval = setInterval(() => fetchQuotes(DEFAULT_SYMBOLS), 10000);
    return () => clearInterval(interval);
  }, [fetchQuotes]);

  /* Search stocks */
  const searchStocks = useCallback(async (q) => {
    if (!q || q.length < 1) { setSearchResults([]); return; }
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
      if (!res.ok) return;
      const data = await res.json();
      setSearchResults(data.results || []);
    } catch {}
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => searchStocks(searchInput), 300);
    return () => clearTimeout(timer);
  }, [searchInput, searchStocks]);

  /* Load from localStorage */
  useEffect(() => {
    try {
      const u = localStorage.getItem("mda-user");
      if (u) setRegistered(JSON.parse(u));
      const p = localStorage.getItem("mda-portfolio");
      if (p) setPortfolio(JSON.parse(p));
      const lb = localStorage.getItem("mda-leaderboard");
      if (lb) setLeaderboard(JSON.parse(lb));
    } catch {}
  }, []);

  const savePortfolio = useCallback((np) => {
    setPortfolio(np);
    localStorage.setItem("mda-portfolio", JSON.stringify(np));
    if (registered) {
      let tv = np.cash;
      np.positions.forEach(p => { const q = quotes[p.ticker]; tv += (q?.price || p.lastPrice || p.avgPrice) * p.qty; });
      const entry = { username: registered.username, email: registered.email, totalValue: Math.round(tv * 100) / 100, pnl: Math.round((tv - STARTING_CASH) * 100) / 100, pnlPercent: ((tv - STARTING_CASH) / STARTING_CASH * 100).toFixed(2), trades: np.trades.length };
      const lb = JSON.parse(localStorage.getItem("mda-leaderboard") || "[]");
      const idx = lb.findIndex(l => l.username === registered.username);
      if (idx >= 0) lb[idx] = entry; else lb.push(entry);
      lb.sort((a, b) => b.totalValue - a.totalValue);
      setLeaderboard(lb);
      localStorage.setItem("mda-leaderboard", JSON.stringify(lb));
    }
  }, [registered, quotes]);

  const handleRegister = () => {
    if (!regForm.username.trim() || !regForm.email.trim()) return notify("Fill in all fields", "error");
    const u = { username: regForm.username.trim(), email: regForm.email.trim() };
    setRegistered(u);
    localStorage.setItem("mda-user", JSON.stringify(u));
    setShowRegister(false);
    notify(`Welcome to MDA, ${u.username}!`);
  };

  const getQuote = (sym) => quotes[sym] || null;
  const getPrice = (sym) => quotes[sym]?.price || 0;
  const getChange = (sym) => quotes[sym]?.changePercent || 0;

  /* Open trade — price comes from already-fetched quotes */
  const openTrade = async (type) => {
    /* Refresh this specific ticker's price */
    await fetchQuotes([symbol]);
    setTradeModal(type);
    setTradeQty(1);
    setStrikePrice("");
  };

  const executeTrade = (type) => {
    const price = getPrice(symbol);
    if (!price || price <= 0) return notify("Price not available — try again", "error");
    const qty = parseInt(tradeQty) || 0;
    if (qty <= 0) return notify("Enter valid quantity", "error");
    const np = JSON.parse(JSON.stringify(portfolio));
    const trade = { type, ticker: symbol, qty, price, time: new Date().toISOString() };

    if (type === "buy") {
      if (price * qty > np.cash) return notify(`Need ${fmt(price * qty)} — have ${fmt(np.cash)}`, "error");
      np.cash -= price * qty;
      const ex = np.positions.find(p => p.ticker === symbol && p.type === "long");
      if (ex) { ex.avgPrice = ((ex.avgPrice * ex.qty) + price * qty) / (ex.qty + qty); ex.qty += qty; ex.lastPrice = price; }
      else np.positions.push({ ticker: symbol, type: "long", qty, avgPrice: price, lastPrice: price });
    } else if (type === "sell") {
      const ex = np.positions.find(p => p.ticker === symbol && p.type === "long");
      if (!ex || ex.qty < qty) return notify("Not enough shares", "error");
      np.cash += price * qty; ex.qty -= qty; ex.lastPrice = price;
      if (ex.qty === 0) np.positions = np.positions.filter(p => p !== ex);
    } else if (type === "short") {
      const margin = price * qty * 0.5;
      if (margin > np.cash) return notify(`Need ${fmt(margin)} margin`, "error");
      np.cash -= margin;
      np.positions.push({ ticker: symbol, type: "short", qty, avgPrice: price, margin, lastPrice: price });
    } else if (type === "cover") {
      const ex = np.positions.find(p => p.ticker === symbol && p.type === "short");
      if (!ex || ex.qty < qty) return notify("No short to cover", "error");
      np.cash += ((ex.margin || 0) * (qty / ex.qty)) + (ex.avgPrice - price) * qty;
      ex.qty -= qty; ex.lastPrice = price;
      if (ex.qty === 0) np.positions = np.positions.filter(p => p !== ex);
    } else if (type === "call" || type === "put") {
      const premium = price * 0.05 * qty * 100;
      if (premium > np.cash) return notify(`Need ${fmt(premium)} premium`, "error");
      np.cash -= premium;
      np.positions.push({ ticker: symbol, type: `option_${type}`, qty, strikePrice: parseFloat(strikePrice) || price, premium, expiry, avgPrice: premium / (qty * 100), lastPrice: price });
      trade.premium = premium;
    }

    np.trades.unshift(trade);
    savePortfolio(np);
    setTradeModal(null);
    notify(`${{ buy:"Bought",sell:"Sold",short:"Shorted",cover:"Covered",call:"Call",put:"Put" }[type]} ${qty} ${symbol} @ ${fmt(price)}`);
  };

  const portfolioData = useMemo(() => {
    let tv = portfolio.cash;
    const enriched = portfolio.positions.map(pos => {
      const cur = quotes[pos.ticker]?.price || pos.lastPrice || pos.avgPrice;
      let value = cur * pos.qty, pnl = (cur - pos.avgPrice) * pos.qty;
      if (pos.type === "short") { pnl = (pos.avgPrice - cur) * pos.qty; value = (pos.margin || 0) + pnl; }
      else if (pos.type?.startsWith("option_")) { value = pos.premium || 0; pnl = 0; }
      tv += value;
      return { ...pos, curPrice: cur, value, pnl };
    });
    return { positions: enriched, totalVal: tv, totalPnl: tv - STARTING_CASH };
  }, [portfolio, quotes]);

  const filteredSymbols = searchInput
    ? (searchResults.length > 0 ? searchResults.map(r => r.symbol) : DEFAULT_SYMBOLS.filter(s => s.toLowerCase().includes(searchInput.toLowerCase())))
    : DEFAULT_SYMBOLS;

  const curQuote = getQuote(symbol);
  const curPrice = getPrice(symbol);
  const curChange = getChange(symbol);
  const longPos = portfolio.positions.find(p => p.ticker === symbol && p.type === "long");
  const shortPos = portfolio.positions.find(p => p.ticker === symbol && p.type === "short");

  return (
    <>
      <Head><title>MDA Stock Investing Club</title><meta name="viewport" content="width=device-width, initial-scale=1" /></Head>

      {notification && <div style={{ position: "fixed", top: 14, left: "50%", transform: "translateX(-50%)", zIndex: 9999, padding: "11px 22px", borderRadius: 10, background: notification.type === "error" ? R : G, color: notification.type === "error" ? "#fff" : "#000", fontWeight: 700, fontSize: 13, animation: "fadeIn .3s ease", boxShadow: "0 8px 32px rgba(0,0,0,.5)" }}>{notification.msg}</div>}
      {showAI && <AIModal ticker={symbol} onClose={() => setShowAI(false)} />}

      {/* Trade Modal */}
      {tradeModal && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,.75)", backdropFilter: "blur(10px)" }} onClick={() => setTradeModal(null)}>
          <div onClick={e => e.stopPropagation()} style={{ background: C1, border: `1px solid ${BD}`, borderRadius: 16, width: 420, padding: 24, animation: "slideUp .3s ease" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <h3 style={{ fontSize: 18, fontWeight: 800 }}>{{ buy:"Buy",sell:"Sell",short:"Short",cover:"Cover",call:"Call",put:"Put" }[tradeModal]} — {symbol}</h3>
              <button onClick={() => setTradeModal(null)} style={{ background: "none", border: "none", color: MT, cursor: "pointer", fontSize: 18 }}>✕</button>
            </div>
            <div style={{ background: C2, border: `1px solid ${BD}`, borderRadius: 10, padding: 16, marginBottom: 16, textAlign: "center" }}>
              <div style={{ fontSize: 10, color: MT, textTransform: "uppercase", letterSpacing: ".07em", marginBottom: 6 }}>Real-Time Price</div>
              <div className="mono" style={{ fontSize: 34, fontWeight: 800, color: curChange >= 0 ? G : R }}>{curPrice ? fmt(curPrice) : "Loading..."}</div>
              <div className="mono" style={{ fontSize: 12, color: curChange >= 0 ? G : R, marginTop: 2 }}>{curChange >= 0 ? "+" : ""}{curChange.toFixed(2)}%</div>
              <div style={{ fontSize: 9, color: G, marginTop: 4, display: "flex", alignItems: "center", justifyContent: "center", gap: 4 }}>
                <span style={{ width: 5, height: 5, borderRadius: "50%", background: G, animation: "pulse 2s infinite" }} />
                Yahoo Finance — refreshes every 10s
              </div>
            </div>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 10, color: MT, textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 5, fontWeight: 500, display: "block" }}>Quantity</label>
              <input type="number" min="1" value={tradeQty} onChange={e => setTradeQty(e.target.value)} style={{ background: "#08080e", border: `1px solid ${BD}`, color: TX, padding: "10px 14px", borderRadius: 8, fontSize: 14, fontFamily: "'JetBrains Mono'", width: "100%", outline: "none" }} />
            </div>
            {(tradeModal === "call" || tradeModal === "put") && <>
              <div style={{ marginBottom: 12 }}><label style={{ fontSize: 10, color: MT, textTransform: "uppercase", display: "block", marginBottom: 5 }}>Strike Price</label><input type="number" step="0.01" value={strikePrice} onChange={e => setStrikePrice(e.target.value)} style={{ background: "#08080e", border: `1px solid ${BD}`, color: TX, padding: "10px 14px", borderRadius: 8, fontSize: 14, fontFamily: "'JetBrains Mono'", width: "100%", outline: "none" }} /></div>
              <div style={{ marginBottom: 12 }}><label style={{ fontSize: 10, color: MT, textTransform: "uppercase", display: "block", marginBottom: 5 }}>Expiration</label><input type="date" value={expiry} onChange={e => setExpiry(e.target.value)} style={{ background: "#08080e", border: `1px solid ${BD}`, color: TX, padding: "10px 14px", borderRadius: 8, fontSize: 14, width: "100%", outline: "none", fontFamily: "inherit" }} /></div>
            </>}
            <div style={{ background: C2, border: `1px solid ${BD}`, borderRadius: 10, padding: 10, marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 3 }}><span style={{ color: MT }}>Cash</span><span className="mono" style={{ fontWeight: 600, color: G }}>{fmt(portfolio.cash)}</span></div>
              {curPrice > 0 && <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, fontWeight: 700 }}><span>Total</span><span className="mono">{fmt(curPrice * (parseInt(tradeQty) || 1))}</span></div>}
            </div>
            <button onClick={() => executeTrade(tradeModal)} style={{ width: "100%", padding: 13, fontSize: 15, border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 700, fontFamily: "inherit", background: tradeModal === "sell" || tradeModal === "short" || tradeModal === "put" ? R : G, color: tradeModal === "sell" || tradeModal === "short" || tradeModal === "put" ? "#fff" : "#000" }}>
              {{ buy:"Buy",sell:"Sell",short:"Short",cover:"Cover",call:"Buy Call",put:"Buy Put" }[tradeModal]} {symbol} {curPrice ? `@ ${fmt(curPrice)}` : ""}
            </button>
          </div>
        </div>
      )}

      {/* Register */}
      {showRegister && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,.75)", backdropFilter: "blur(10px)" }} onClick={() => setShowRegister(false)}>
          <div onClick={e => e.stopPropagation()} style={{ background: C1, border: `1px solid ${BD}`, borderRadius: 16, width: 400, padding: 32, animation: "slideUp .3s ease" }}>
            <h3 style={{ fontSize: 22, fontWeight: 900, marginBottom: 4 }}>Join MDA</h3>
            <p style={{ color: MT, fontSize: 13, marginBottom: 22 }}>Register for the leaderboard</p>
            <div style={{ marginBottom: 14 }}><label style={{ fontSize: 10, color: MT, textTransform: "uppercase", display: "block", marginBottom: 5 }}>Username</label><input type="text" placeholder="Display name" value={regForm.username} onChange={e => setRegForm(f => ({ ...f, username: e.target.value }))} style={{ background: "#08080e", border: `1px solid ${BD}`, color: TX, padding: "10px 14px", borderRadius: 8, fontSize: 14, width: "100%", outline: "none", fontFamily: "inherit" }} /></div>
            <div style={{ marginBottom: 20 }}><label style={{ fontSize: 10, color: MT, textTransform: "uppercase", display: "block", marginBottom: 5 }}>Email</label><input type="text" placeholder="you@email.com" value={regForm.email} onChange={e => setRegForm(f => ({ ...f, email: e.target.value }))} style={{ background: "#08080e", border: `1px solid ${BD}`, color: TX, padding: "10px 14px", borderRadius: 8, fontSize: 14, width: "100%", outline: "none", fontFamily: "inherit" }} /></div>
            <button onClick={handleRegister} style={{ width: "100%", padding: 12, fontSize: 15, border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 700, fontFamily: "inherit", background: G, color: "#000" }}>Create Account</button>
          </div>
        </div>
      )}

      {/* NAV */}
      <nav style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 24px", height: 52, borderBottom: `1px solid ${BD}`, background: "rgba(6,6,9,.94)", backdropFilter: "blur(24px)", position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 28, height: 28, borderRadius: 7, background: `linear-gradient(135deg,${G},#00c853)`, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 900, fontSize: 12, color: "#000", animation: "glow 3s infinite" }}>M</div>
          <span style={{ fontWeight: 900, fontSize: 16, letterSpacing: "-.03em" }}>MDA</span>
        </div>
        <div style={{ display: "flex", gap: 2 }}>
          {[{ id: "home", l: "Home" }, { id: "trade", l: "Trade" }, { id: "portfolio", l: "Portfolio" }, { id: "leaderboard", l: "Leaderboard" }].map(n => (
            <div key={n.id} onClick={() => setPage(n.id)} style={{ cursor: "pointer", padding: "7px 14px", borderRadius: 8, fontSize: 13, fontWeight: 500, color: page === n.id ? G : MT, background: page === n.id ? `${G}10` : "transparent", transition: "all .15s" }}>{n.l}</div>
          ))}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span className="mono" style={{ fontSize: 13, fontWeight: 600, color: G }}>{fmt(portfolio.cash)}</span>
          {registered ? <div style={{ height: 28, padding: "0 10px", borderRadius: 7, background: C2, border: `1px solid ${BD}`, display: "flex", alignItems: "center", fontSize: 12, fontWeight: 600, gap: 5 }}><div style={{ width: 5, height: 5, borderRadius: "50%", background: G }} />{registered.username}</div>
          : <button onClick={() => setShowRegister(true)} style={{ padding: "5px 12px", fontSize: 11, border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 600, background: G, color: "#000", fontFamily: "inherit" }}>Sign Up</button>}
        </div>
      </nav>
      <div style={{ borderBottom: `1px solid ${BD}`, height: 46, overflow: "hidden" }}><TVTicker /></div>

      {/* HOME */}
      {page === "home" && (
        <div className="fade" style={{ maxWidth: 900, margin: "0 auto", padding: "48px 28px", textAlign: "center" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "4px 14px", borderRadius: 100, border: `1px solid ${BD}`, fontSize: 11, color: MT, marginBottom: 22 }}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: G, animation: "pulse 2s infinite" }} />REAL-TIME YAHOO FINANCE DATA
          </div>
          <h1 style={{ fontSize: 56, fontWeight: 900, lineHeight: 1, letterSpacing: "-.045em", marginBottom: 14 }}>
            <span style={{ background: `linear-gradient(135deg,${TX},${MT})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>MDA Stock</span><br />
            <span style={{ background: `linear-gradient(135deg,${G},#69f0ae)`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Investing Club</span>
          </h1>
          <p style={{ fontSize: 15, color: MT, margin: "0 auto 6px" }}>Founded by <span style={{ color: TX, fontWeight: 700 }}>Jack & Joseph Mizrachi</span></p>
          <p style={{ fontSize: 14, color: MT, maxWidth: 460, margin: "0 auto 30px", lineHeight: 1.6 }}>Real prices from Yahoo Finance. Search any stock. Short sell, options, AI analysis, and leaderboard. $5,000 virtual capital.</p>
          <div style={{ display: "flex", gap: 10, justifyContent: "center", marginBottom: 36 }}>
            <button onClick={() => setPage("trade")} style={{ padding: "13px 30px", fontSize: 15, border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 700, background: G, color: "#000", fontFamily: "inherit" }}>Start Trading</button>
            <button onClick={() => setPage("leaderboard")} style={{ padding: "13px 30px", fontSize: 15, border: `1px solid ${BD}`, borderRadius: 8, cursor: "pointer", fontWeight: 700, background: "transparent", color: TX, fontFamily: "inherit" }}>Leaderboard</button>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10, marginBottom: 36 }}>
            {["AAPL", "NVDA", "TSLA", "META"].map(t => {
              const q = getQuote(t);
              return (
                <div key={t} onClick={() => { setSymbol(t); setPage("trade"); }} style={{ background: C1, border: `1px solid ${BD}`, borderRadius: 12, padding: 16, cursor: "pointer", transition: "all .15s" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                    <span style={{ fontWeight: 700, fontSize: 15 }}>{t}</span>
                    {q && <span style={{ display: "inline-block", padding: "3px 10px", borderRadius: 100, fontSize: 11, fontWeight: 600, fontFamily: "'JetBrains Mono'", background: q.changePercent >= 0 ? `${G}15` : `${R}15`, color: q.changePercent >= 0 ? G : R }}>{q.changePercent >= 0 ? "+" : ""}{q.changePercent.toFixed(2)}%</span>}
                  </div>
                  <div className="mono" style={{ fontSize: 20, fontWeight: 700 }}>{q ? fmt(q.price) : "..."}</div>
                  <div style={{ fontSize: 10, color: MT, marginTop: 4 }}>{q?.name || ""}</div>
                </div>
              );
            })}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10 }}>
            {[{ l: "Budget", v: "$5,000" }, { l: "Prices", v: "YAHOO FIN.", c: G }, { l: "Stocks", v: "Any Ticker" }, { l: "Features", v: "Options+Shorts" }].map((s, i) => (
              <div key={i} style={{ background: C1, border: `1px solid ${BD}`, borderRadius: 12, padding: 16 }}><div style={{ fontSize: 9, color: MT, textTransform: "uppercase", letterSpacing: ".07em", marginBottom: 4 }}>{s.l}</div><div className="mono" style={{ fontSize: 18, fontWeight: 800, color: s.c || TX }}>{s.v}</div></div>
            ))}
          </div>
        </div>
      )}

      {/* TRADE */}
      {page === "trade" && (
        <div className="fade" style={{ display: "grid", gridTemplateColumns: "250px 1fr 250px", height: "calc(100vh - 99px)" }}>
          {/* Sidebar — REAL prices from Yahoo Finance */}
          <div style={{ borderRight: `1px solid ${BD}`, display: "flex", flexDirection: "column", overflow: "hidden" }}>
            <div style={{ padding: "8px 10px", borderBottom: `1px solid ${BD}` }}>
              <input type="text" placeholder="Search any stock..." value={searchInput} onChange={e => setSearchInput(e.target.value)} style={{ background: "#08080e", border: `1px solid ${BD}`, color: TX, padding: "7px 10px", borderRadius: 8, fontSize: 12, width: "100%", outline: "none", fontFamily: "inherit" }} />
            </div>
            <div style={{ overflowY: "auto", flex: 1 }}>
              {filteredSymbols.map(sym => {
                const q = getQuote(sym);
                return (
                  <div key={sym} onClick={() => { setSymbol(sym); setSearchInput(""); setSearchResults([]); if (!q) fetchQuotes([sym]); }} style={{ cursor: "pointer", padding: "8px 12px", borderBottom: `1px solid ${BD}`, transition: "all .1s", display: "flex", alignItems: "center", justifyContent: "space-between", background: symbol === sym ? "#0e0e16" : "transparent", borderLeft: symbol === sym ? `2px solid ${G}` : "2px solid transparent" }}>
                    <div>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span style={{ fontWeight: 700, fontSize: 13 }}>{sym}</span>
                        {portfolio.positions.some(p => p.ticker === sym) && <div style={{ width: 5, height: 5, borderRadius: "50%", background: G }} />}
                      </div>
                      <div style={{ fontSize: 9, color: MT }}>{q?.name || sym}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      {q ? <>
                        <div className="mono" style={{ fontSize: 12, fontWeight: 600 }}>{fmt(q.price)}</div>
                        <div className="mono" style={{ fontSize: 10, color: q.changePercent >= 0 ? G : R }}>{q.changePercent >= 0 ? "+" : ""}{q.changePercent.toFixed(2)}%</div>
                      </> : <div style={{ fontSize: 10, color: MT }}>...</div>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Chart */}
          <div style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
            <div style={{ flex: 1, minHeight: 0 }}><TVChart symbol={symbol} /></div>
          </div>

          {/* Trade Panel */}
          <div style={{ borderLeft: `1px solid ${BD}`, padding: 10, display: "flex", flexDirection: "column", gap: 8, overflowY: "auto" }}>
            <div style={{ textAlign: "center", padding: "8px 0" }}>
              <div className="mono" style={{ fontSize: 20, fontWeight: 900 }}>{symbol}</div>
              <div className="mono" style={{ fontSize: 24, fontWeight: 800, color: curChange >= 0 ? G : R, marginTop: 2 }}>{curPrice ? fmt(curPrice) : "..."}</div>
              <div className="mono" style={{ fontSize: 11, color: curChange >= 0 ? G : R }}>{curPrice ? `${curChange >= 0 ? "+" : ""}${curChange.toFixed(2)}%` : ""}</div>
              <div style={{ fontSize: 9, color: G, marginTop: 3 }}>Yahoo Finance · live</div>
            </div>

            <button onClick={() => setShowAI(true)} style={{ width: "100%", padding: 8, background: "linear-gradient(135deg,#14142a,#1a1a36)", border: "1px solid #2a2a50", borderRadius: 8, color: "#818cf8", fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, fontSize: 12, fontFamily: "inherit" }}>
              <span style={{ fontSize: 14 }}>✦</span> AI Analysis
            </button>

            <div style={{ background: C2, border: `1px solid ${BD}`, borderRadius: 10, padding: 10 }}>
              <div style={{ fontSize: 9, color: MT, textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 6 }}>Stocks</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 }}>
                {[["Buy","buy",G,"#000"],["Sell","sell",R,"#fff"],["Short","short","transparent","#fff"],["Cover","cover","transparent","#fff"]].map(([l,t,bg,c]) => (
                  <button key={t} onClick={() => openTrade(t)} style={{ padding: 8, fontSize: 12, border: bg === "transparent" ? `1px solid ${BD}` : "none", borderRadius: 8, cursor: "pointer", fontWeight: 600, background: bg, color: c, fontFamily: "inherit" }}>{l}</button>
                ))}
              </div>
            </div>
            <div style={{ background: C2, border: `1px solid ${BD}`, borderRadius: 10, padding: 10 }}>
              <div style={{ fontSize: 9, color: MT, textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 6 }}>Options</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 }}>
                <button onClick={() => openTrade("call")} style={{ padding: 8, fontSize: 11, background: "#0d2818", color: "#4caf50", border: "1px solid #1b5e20", borderRadius: 8, cursor: "pointer", fontWeight: 600, fontFamily: "inherit" }}>Call</button>
                <button onClick={() => openTrade("put")} style={{ padding: 8, fontSize: 11, background: "#2a0a0a", color: "#ef5350", border: "1px solid #b71c1c", borderRadius: 8, cursor: "pointer", fontWeight: 600, fontFamily: "inherit" }}>Put</button>
              </div>
            </div>
            <div style={{ background: C2, border: `1px solid ${BD}`, borderRadius: 10, padding: 10 }}>
              <div style={{ fontSize: 9, color: MT, textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 5 }}>Position — {symbol}</div>
              {longPos && <div style={{ fontSize: 11 }}><span style={{ color: G }}>LONG</span> <span className="mono">{longPos.qty}</span> @ <span className="mono">{fmt(longPos.avgPrice)}</span></div>}
              {shortPos && <div style={{ fontSize: 11 }}><span style={{ color: R }}>SHORT</span> <span className="mono">{shortPos.qty}</span> @ <span className="mono">{fmt(shortPos.avgPrice)}</span></div>}
              {!longPos && !shortPos && <div style={{ fontSize: 10, color: MT }}>No position</div>}
            </div>
            <div style={{ background: C2, border: `1px solid ${BD}`, borderRadius: 10, padding: 10 }}>
              <div style={{ fontSize: 9, color: MT, textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 5 }}>Account</div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 2 }}><span style={{ color: MT }}>Cash</span><span className="mono" style={{ fontWeight: 600, color: G }}>{fmt(portfolio.cash)}</span></div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12 }}><span style={{ color: MT }}>P&L</span><span className="mono" style={{ fontWeight: 600, color: portfolioData.totalPnl >= 0 ? G : R }}>{portfolioData.totalPnl >= 0 ? "+" : ""}{fmt(portfolioData.totalPnl)}</span></div>
            </div>
            <div style={{ background: C2, border: `1px solid ${BD}`, borderRadius: 10, padding: 10, flex: 1, overflow: "auto" }}>
              <div style={{ fontSize: 9, color: MT, textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 5 }}>Trades</div>
              {portfolio.trades.length === 0 ? <div style={{ color: MT, fontSize: 10, textAlign: "center", padding: 8 }}>No trades yet</div> :
                portfolio.trades.slice(0, 15).map((t, i) => (
                  <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", borderBottom: `1px solid ${BD}`, fontSize: 10 }}>
                    <div><span className="mono" style={{ fontWeight: 700, color: t.type === "buy" || t.type === "call" ? G : R, marginRight: 3 }}>{t.type.toUpperCase()}</span>{t.qty} {t.ticker}</div>
                    <span className="mono" style={{ color: MT }}>{fmt(t.price)}</span>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* PORTFOLIO */}
      {page === "portfolio" && (
        <div className="fade" style={{ maxWidth: 960, margin: "0 auto", padding: 28 }}>
          <h2 style={{ fontSize: 24, fontWeight: 900, marginBottom: 20 }}>Portfolio</h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10, marginBottom: 22 }}>
            {[{ l: "Total Value", v: fmt(portfolioData.totalVal), c: portfolioData.totalPnl >= 0 ? G : R }, { l: "Cash", v: fmt(portfolio.cash) }, { l: "P&L", v: `${portfolioData.totalPnl >= 0 ? "+" : ""}${fmt(portfolioData.totalPnl)}`, c: portfolioData.totalPnl >= 0 ? G : R }, { l: "Return", v: `${portfolioData.totalPnl >= 0 ? "+" : ""}${(portfolioData.totalPnl / STARTING_CASH * 100).toFixed(2)}%`, c: portfolioData.totalPnl >= 0 ? G : R }].map((s, i) => (
              <div key={i} style={{ background: C1, border: `1px solid ${BD}`, borderRadius: 12, padding: "16px 18px" }}><div style={{ fontSize: 10, color: MT, textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 5 }}>{s.l}</div><div className="mono" style={{ fontSize: 22, fontWeight: 800, color: s.c || TX }}>{s.v}</div></div>
            ))}
          </div>
          <div style={{ background: C1, border: `1px solid ${BD}`, borderRadius: 12, padding: 20, marginBottom: 18 }}>
            <h3 style={{ fontSize: 14, fontWeight: 800, marginBottom: 14 }}>Holdings</h3>
            {portfolioData.positions.length === 0 ? <div style={{ textAlign: "center", padding: "36px 0", color: MT }}>No holdings — <span style={{ color: G, cursor: "pointer" }} onClick={() => setPage("trade")}>start trading</span></div>
            : <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead><tr style={{ borderBottom: `1px solid ${BD}` }}>{["Ticker","Type","Qty","Avg Cost","Live Price","Value","P&L"].map((h,i) => <th key={i} style={{ textAlign: i > 2 ? "right" : "left", padding: "7px 8px", color: MT, fontWeight: 500, fontSize: 9, textTransform: "uppercase" }}>{h}</th>)}</tr></thead>
              <tbody>{portfolioData.positions.map((pos,i) => (
                <tr key={i} style={{ borderBottom: `1px solid ${BD}` }}>
                  <td className="mono" style={{ padding: "11px 8px", fontWeight: 700 }}>{pos.ticker}</td>
                  <td style={{ padding: "11px 8px" }}><span style={{ display: "inline-block", padding: "3px 10px", borderRadius: 100, fontSize: 11, fontWeight: 600, fontFamily: "'JetBrains Mono'", background: pos.type === "long" ? `${G}15` : pos.type === "short" ? `${R}15` : "#818cf815", color: pos.type === "long" ? G : pos.type === "short" ? R : "#818cf8" }}>{pos.type.replace("option_","").toUpperCase()}</span></td>
                  <td className="mono" style={{ padding: "11px 8px" }}>{pos.qty}</td>
                  <td className="mono" style={{ padding: "11px 8px", textAlign: "right" }}>{fmt(pos.avgPrice)}</td>
                  <td className="mono" style={{ padding: "11px 8px", textAlign: "right", fontWeight: 600, color: pos.curPrice > pos.avgPrice ? G : pos.curPrice < pos.avgPrice ? R : TX }}>{fmt(pos.curPrice)}</td>
                  <td className="mono" style={{ padding: "11px 8px", textAlign: "right", fontWeight: 600 }}>{fmt(pos.value)}</td>
                  <td className="mono" style={{ padding: "11px 8px", textAlign: "right", fontWeight: 700, color: pos.pnl >= 0 ? G : R }}>{pos.pnl >= 0 ? "+" : ""}{fmt(pos.pnl)}</td>
                </tr>
              ))}</tbody>
            </table>}
          </div>
          <div style={{ background: C1, border: `1px solid ${BD}`, borderRadius: 12, padding: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 800, marginBottom: 14 }}>Trade History</h3>
            {portfolio.trades.length === 0 ? <div style={{ color: MT, textAlign: "center", padding: 20 }}>No trades</div> :
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
              <thead><tr style={{ borderBottom: `1px solid ${BD}` }}>{["Time","Type","Ticker","Qty","Price","Total"].map((h,i) => <th key={i} style={{ textAlign: i > 2 ? "right" : "left", padding: "6px 8px", color: MT, fontWeight: 500, fontSize: 9, textTransform: "uppercase" }}>{h}</th>)}</tr></thead>
              <tbody>{portfolio.trades.map((t,i) => (
                <tr key={i} style={{ borderBottom: `1px solid ${BD}` }}>
                  <td style={{ padding: 8, color: MT, fontSize: 10 }}>{new Date(t.time).toLocaleString()}</td>
                  <td style={{ padding: 8 }}><span className="mono" style={{ fontWeight: 700, color: t.type === "buy" || t.type === "call" ? G : R }}>{t.type.toUpperCase()}</span></td>
                  <td className="mono" style={{ padding: 8, fontWeight: 600 }}>{t.ticker}</td>
                  <td className="mono" style={{ padding: 8, textAlign: "right" }}>{t.qty}</td>
                  <td className="mono" style={{ padding: 8, textAlign: "right" }}>{fmt(t.price)}</td>
                  <td className="mono" style={{ padding: 8, textAlign: "right", fontWeight: 600 }}>{fmt(t.price * t.qty)}</td>
                </tr>
              ))}</tbody>
            </table>}
          </div>
        </div>
      )}

      {/* LEADERBOARD */}
      {page === "leaderboard" && (
        <div className="fade" style={{ maxWidth: 760, margin: "0 auto", padding: 28 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <div><h2 style={{ fontSize: 24, fontWeight: 900, marginBottom: 2 }}>Leaderboard</h2><p style={{ color: MT, fontSize: 13 }}>MDA Club rankings</p></div>
          </div>
          {!registered && <div style={{ background: C1, border: `1px solid ${G}20`, borderRadius: 12, padding: 20, marginBottom: 16, textAlign: "center" }}><div style={{ fontSize: 14, marginBottom: 10 }}>Sign up to appear on the leaderboard</div><button onClick={() => setShowRegister(true)} style={{ padding: "8px 20px", border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 700, background: G, color: "#000", fontFamily: "inherit" }}>Join MDA</button></div>}
          <div style={{ background: C1, border: `1px solid ${BD}`, borderRadius: 12, overflow: "hidden" }}>
            <div style={{ display: "grid", gridTemplateColumns: "44px 1fr 120px 80px 60px", padding: "10px 16px", borderBottom: `1px solid ${BD}`, fontSize: 9, color: MT, textTransform: "uppercase", letterSpacing: ".06em" }}><div>Rank</div><div>Trader</div><div style={{ textAlign: "right" }}>Value</div><div style={{ textAlign: "right" }}>P&L</div><div style={{ textAlign: "right" }}>Trades</div></div>
            {leaderboard.length === 0 ? <div style={{ padding: "36px 0", textAlign: "center", color: MT }}>No members yet</div>
            : leaderboard.map((m, i) => {
              const isMe = registered && m.username === registered.username;
              return (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "44px 1fr 120px 80px 60px", alignItems: "center", padding: "12px 16px", borderBottom: i < leaderboard.length - 1 ? `1px solid ${BD}` : "none", background: isMe ? `${G}06` : "transparent" }}>
                  <div className="mono" style={{ fontSize: 14, fontWeight: 800, color: i < 3 ? G : MT }}>{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `#${i+1}`}</div>
                  <div><div style={{ fontWeight: isMe ? 700 : 500, fontSize: 14, color: isMe ? G : TX }}>{m.username} {isMe && <span style={{ fontSize: 9, color: MT }}>(you)</span>}</div><div style={{ fontSize: 10, color: MT }}>{m.email}</div></div>
                  <div className="mono" style={{ textAlign: "right", fontSize: 13, fontWeight: 600 }}>{fmt(m.totalValue)}</div>
                  <div className="mono" style={{ textAlign: "right", fontSize: 12, fontWeight: 600, color: m.pnl >= 0 ? G : R }}>{m.pnl >= 0 ? "+" : ""}{parseFloat(m.pnlPercent).toFixed(2)}%</div>
                  <div className="mono" style={{ textAlign: "right", fontSize: 12, color: MT }}>{m.trades}</div>
                </div>
              );
            })}
          </div>
          <div style={{ fontSize: 10, color: MT, textAlign: "center", marginTop: 12 }}>Leaderboard is stored locally. For shared leaderboard, connect a database (see README).</div>
        </div>
      )}
    </>
  );
}
